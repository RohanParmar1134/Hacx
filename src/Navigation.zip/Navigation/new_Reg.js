import React from 'react'
import { useState } from 'react';
export default function New_Reg() {
    const [formData, setFormData] = useState({
        name: '',
        age: '',
        aadharNumber: '',
        dob: '',
        email: ''
      });
    
      const handleOnSubmit = async (e) => {
        e.preventDefault();
      }

      const handleInputChange = (event) => {
        const { name, value } = event.target;
        setFormData((prevData) => ({
          ...prevData,
          [name]: value,
        }));
      };
  return (
    <div className="">
        <form className="" onSubmit={handleOnSubmit}>
          <h2>Add Information</h2>
          <div className="">
            <label>Name</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              required
            />
          </div>
          <div className="">
            <label>Age</label>
            <input
              type="text"
              name="age"
              value={formData.age}
              onChange={handleInputChange}
              required
            />
          </div>
          <div className="">
            <label>Email</label>
            <input
              type="text"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
              required
            />
          </div>
          <div className="">
            <label>Aadhar Card Number</label>
            <input
              type="text"
              name="aadharNumber"
              value={formData.aadharNumber}
              onChange={handleInputChange}
              required
            />
          </div>
          <div className="">
            <label>D.O.B</label>
            <input type="date"
              name="prescription"
              value={formData.prescription}
              onChange={handleInputChange}
              rows="4"
            />
          </div>


          <button type="submit">Submit</button>
        </form>
      </div>
  )
}
